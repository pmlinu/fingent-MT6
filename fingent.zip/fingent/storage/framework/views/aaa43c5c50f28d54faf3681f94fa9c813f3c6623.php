<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Student Marks'); ?>
<div class="push-top">
    <?php if(session()->get('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('success')); ?>  
        </div><br />
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12 p-4 ">
            <a href="<?php echo e(route('createMark')); ?>" class="btn btn-primary btn-sm float-right">Create Student Mark </a>
            <a href="<?php echo e(route('student')); ?>" class="btn btn-primary btn-sm float-right mr-2">Student</a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <table class="table">
                <thead>
                    <tr class="">
                        <td>ID</td>
                        <td>Name</td>
                        <td>Maths</td>
                        <td>Science</td>
                        <td>History</td>
                        <td>Term</td>
                        <td>Total Marks</td>
                        <td>Created On</td>
                        <td class="text-center">Action</td>
                    </tr>
                </thead>
            <tbody>
                    <?php if(count($studentMarks) > 0): ?>
                        <?php $__currentLoopData = $studentMarks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $studentMark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="">
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($studentMark->student->name); ?></td>
                                <td><?php echo e($studentMark->maths); ?></td>
                                <td><?php echo e($studentMark->science); ?></td>
                                <td><?php echo e($studentMark->history); ?></td>
                                <td><?php echo e($studentMark->term); ?></td>
                                <td><?php echo e($studentMark->total_mark); ?></td>
                                <td><?php echo e($studentMark->created_at); ?></td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('editMark', $studentMark->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                                    <form action="<?php echo e(route('deleteMark', $studentMark->id)); ?>" method="post" style="display: inline-block">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-danger btn-sm" type="submit">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr class="" >
                        <td colspan="9">No data found.</td>
                    </tr>
                    <?php endif; ?>
                   
            </tbody>
          </table>
          <?php echo e($studentMarks->links( "pagination::bootstrap-4")); ?>

        </div>
    </div>
 
<div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/fingent/resources/views/studentmark/index.blade.php ENDPATH**/ ?>