<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Student'); ?>
<div class="push-top">
    <?php if(session()->get('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('success')); ?>  
        </div><br />
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12 p-4 ">
            <a href="<?php echo e(route('createStudent')); ?>" class="btn btn-primary btn-sm float-right">Create Student</a>
            <a href="<?php echo e(route('mark')); ?>" class="btn btn-primary btn-sm float-right mr-2">Mark List</a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <table class="table">
                <thead>
                    <tr class="">
                        <td>ID</td>
                        <td>Name</td>
                        <td>Age</td>
                        <td>Gender</td>
                        <td>Reporting Teacher</td>
                        <td class="text-center">Action</td>
                    </tr>
                </thead>
            <tbody>
                    <?php if(count($students) > 0): ?>
                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="">
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($student->name); ?></td>
                                <td><?php echo e($student->age); ?></td>
                                <td><?php echo e($student->gender); ?></td>
                                <td><?php echo e($student->teacher->name); ?></td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('editStudent', $student->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                                    <form action="<?php echo e(route('deleteStudent', $student->id)); ?>" method="post" style="display: inline-block">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-danger btn-sm" type="submit">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr class="" >
                        <td colspan="6">No data found.</td>
                    </tr>
                    <?php endif; ?>
                   
            </tbody>
          </table>
          <?php echo e($students->links( "pagination::bootstrap-4")); ?>

        </div>
    </div>
 
<div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/fingent/resources/views/student/index.blade.php ENDPATH**/ ?>