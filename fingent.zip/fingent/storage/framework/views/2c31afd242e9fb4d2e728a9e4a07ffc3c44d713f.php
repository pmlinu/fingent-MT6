<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Create Student'); ?>
<div class="card push-top">
    <div class="card-header">
        Add Student
    </div>
    <div class="card-body">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <br />
        <?php endif; ?>
        <form method="post" action="<?php echo e(route('storeStudent')); ?>">
            <div class="form-group">
                <?php echo csrf_field(); ?>
                <label for="name">Name</label>
                <input type="text" class="form-control" name="name" id="name" maxlength="100" value="<?php echo e(old('name')); ?>"/>
            </div>
            <div class="form-group">
                <label for="age">Age</label>
                <input type="text" class="form-control" name="age" id="age" maxlength="2" value="<?php echo e(old('age')); ?>"/>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="gender" id="gender" value="M" value="<?php echo e(old('gender')); ?>" <?php echo e((old('gender') == "M")? "checked" : ""); ?>>
                <label class="form-check-label" for="gender">Male</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="gender" id="gender" value="F" value="<?php echo e(old('gender')); ?>" <?php echo e((old('gender') == "F")? "checked" : ""); ?>>
                <label class="form-check-label" for="gender">Female</label>
            </div>
            <div class="form-group mt-2 mb-0">
                <label for="password">Reporting Teacher</label>
            </div>
            <div class="form-group mt-0">
                <select class="form-select form-control" name="reporting_teacher_id" id="reporting_teacher_id">
                    <option value="">Select</option>
                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(old('reporting_teacher_id') == $teacher->id): ?>
                            <option  value="<?php echo e($teacher->id); ?>" selected="selected"><?php echo e($teacher->name); ?></option>
                        <?php else: ?>
                            <option  value="<?php echo e($teacher->id); ?>"><?php echo e($teacher->name); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <a href="<?php echo e(route('student')); ?>" class="btn btn-primary btn-sm">Cancel</a>
            <button type="submit" class="btn btn-danger btn-sm">Create Student</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/fingent/resources/views/student/create.blade.php ENDPATH**/ ?>